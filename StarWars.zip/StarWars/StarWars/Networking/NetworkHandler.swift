//
//  NetworkHandler.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import Foundation

final class NetworkHandler: NetworkHandleable {
    
    private let urlSession: URLSession
    
    init(urlSession: URLSession = .shared) {
        self.urlSession = urlSession
    }
    
    func executeRequest<T>(type: T.Type, request: URLRequest, completion: @escaping (Result<T, NetworkError>) -> ()) where T : Decodable {
        let task = urlSession.dataTask(with: request) { data, _, error in
            if let error {
                completion(.failure(.apiError(description: error.localizedDescription)))
            } else if let data {
                if let decodedData = try? JSONDecoder().decode(type, from: data) {
                    completion(.success(decodedData))
                } else {
                    completion(.failure(.parsingError))
                }
            }
        }
        task.resume()
    }
}
