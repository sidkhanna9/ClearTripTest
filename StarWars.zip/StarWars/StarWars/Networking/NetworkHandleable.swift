//
//  NetworkHandleable.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import Foundation

protocol NetworkHandleable {
    func executeRequest<T: Decodable>(type: T.Type,
                                      request: URLRequest,
                                      completion: @escaping (Result<T, NetworkError>) -> ())
    
}

enum NetworkError: Error {
    case authError
    case parsingError
    case genericError
    case apiError(description: String)
}
