//
//  HomeViewModel.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import Foundation

final class HomeViewModel: HomeViewModelable {
    
    private let networkHandler: NetworkHandleable
    
    init(networkHandler: NetworkHandleable = NetworkHandler.init()) {
        self.networkHandler = networkHandler
    }
    
    func didLoad() {
        showLoader?(true)
        fetchResponse()
        
    }
    
    func itemSelected(index: Int) {
        if let responseModel = responseModels?[index] {
            
        }
    }
    
    private var responseModels: StarWarsModel? {
        didSet {
            if let responseModels {
                self.createPlayerList(starWarsModels: responseModels)
            } else {
                self.tableViewCellViewModel?([])
            }
        }
    }
    
    var tableViewCellViewModel: (([PointsTableViewCellViewModel]) -> ())?
    var showLoader: ((Bool) -> ())?
    
    private func fetchResponse() {
        guard let url = URL.init(string: "https://api.npoint.io/bc3f07c7442e85446788") else {
            return
        }
        networkHandler.executeRequest(type: StarWarsModel.self, request: .init(url: url)) { [weak self] result in
            self?.showLoader?(false)
            
            switch result {
            case .success(let models):
                self?.responseModels = models
            case .failure(let error):
                self?.responseModels = nil
            }
        }
    }
    
    private func createPlayerList(starWarsModels: StarWarsModel) {
        var playersDictionary: Dictionary<Int, Int> = .init()
        starWarsModels.forEach { starWarsModel in
            let player1Id = starWarsModel.player1.id
            let player2Id = starWarsModel.player2.id
            let player1Score = starWarsModel.player1.score
            let player2Score = starWarsModel.player2.score
            if player1Score > player2Score {
                let player1Wins = playersDictionary[player1Id]
                if let player1Wins {
                    playersDictionary[player1Id] = player1Wins+1
                } else {
                    playersDictionary[player1Id] = 1
                }
                let player2Wins = playersDictionary[player2Id] ?? 0
                playersDictionary[player2Id] = player2Wins
            } else if player1Score < player2Score {
                let player2Wins = playersDictionary[player2Id]
                if let player2Wins {
                    playersDictionary[player2Id] = player2Wins+1
                } else {
                    playersDictionary[player2Id] = 1
                }
                let player1Wins = playersDictionary[player1Id] ?? 0
                playersDictionary[player1Id] = player1Wins
            } else {
                let player1Wins = playersDictionary[player1Id] ?? 0
                let player2Wins = playersDictionary[player2Id] ?? 0
                playersDictionary[player1Id] = player1Wins
                playersDictionary[player2Id] = player2Wins
            }
        }
        
        let players = playersDictionary.keys.sorted(by: <).map { id in
            let player = PlayerModel.init(id: id, wins: playersDictionary[id] ?? 0)
            return player
        }
        self.cellViewModel(players: players)
        
    }
    
    private func cellViewModel(players: [PlayerModel]) {
        let cellsViewModel = players.map { player in
            (name: "\(player.id)", points: "\(player.wins)")
        }
        self.tableViewCellViewModel?(cellsViewModel)
    }
    
    
    private struct PlayerModel {
        let id: Int
        let wins: Int
    }
}
