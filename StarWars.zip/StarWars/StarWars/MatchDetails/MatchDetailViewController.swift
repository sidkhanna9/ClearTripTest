//
//  MatchDetailViewController.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import UIKit

protocol MatchDetailViewModelable: AnyObject {
    func didLoad()
    
    var tableViewCellViewModel: (([PointsTableViewCellViewModel]) -> ())? { get set }
}

final class MatchDetailViewController: UIViewController {
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(PointsTableViewCell.self, forCellReuseIdentifier: "PointsTableViewCell")
        return tableView
    }()
    
    private let activityIndicator: UIActivityIndicatorView = .init()
    
    private var dataSource: [PointsTableViewCellViewModel]? {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    private var viewModel: MatchDetailViewModelable
    
    init(viewModel: MatchDetailViewModelable) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        commonInit()
        viewModel.tableViewCellViewModel = { [weak self] viewModels in
            self?.dataSource = viewModels
        }
        viewModel.didLoad()
    }
    
}

private extension MatchDetailViewController {
    func commonInit() {
        setupHierarchy()
        setupConstraints()
    }
    
    func setupHierarchy() {
        self.view.addSubview(tableView)
        self.view.addSubview(activityIndicator)
    }
    
    func setupConstraints() {
        let viewLayoutGuide = self.view.safeAreaLayoutGuide
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        tableView.topAnchor.constraint(equalTo: viewLayoutGuide.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: viewLayoutGuide.bottomAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: viewLayoutGuide.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: viewLayoutGuide.trailingAnchor).isActive = true
        activityIndicator.centerXAnchor.constraint(equalTo: viewLayoutGuide.centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: viewLayoutGuide.centerYAnchor).isActive = true
    }
}

extension MatchDetailViewController:
    UITableViewDelegate {
}

extension MatchDetailViewController:
    UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.dataSource?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MatchTableViewCell", for: indexPath) as? MatchTableViewCell,
              let cellViewModel = self.dataSource?[indexPath.row] else {
            return .init()
        }
        cell.configure(with: cellViewModel)
        return cell
    }
    
    
}

