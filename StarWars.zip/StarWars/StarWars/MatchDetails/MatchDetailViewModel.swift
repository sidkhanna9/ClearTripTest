//
//  MatchDetailViewModel.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import Foundation

final class MatchDetailViewModel: MatchDetailViewModelable {
    func didLoad() {
        
    }
    
    var tableViewCellViewModel: (([PointsTableViewCellViewModel]) -> ())?
    
    
}
