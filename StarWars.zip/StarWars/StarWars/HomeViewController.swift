//
//  HomeViewController.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import UIKit

protocol HomeViewModelable: AnyObject {
    func didLoad()
    func itemSelected(index: Int)
    
    var showLoader: ((Bool) -> ())? { get set }
    
    var tableViewCellViewModel: (([PointsTableViewCellViewModel]) -> ())? { get set }
}

final class HomeViewController: UIViewController {
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(PointsTableViewCell.self, forCellReuseIdentifier: "PointsTableViewCell")
        return tableView
    }()
    
    private let activityIndicator: UIActivityIndicatorView = .init()
    
    private var dataSource: [PointsTableViewCellViewModel]? {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    private var viewModel: HomeViewModelable?

    override func viewDidLoad() {
        super.viewDidLoad()
        commonInit()
        
        configure(with: HomeViewModel.init())
        
        viewModel?.didLoad()
    }
    
    func configure(with viewModel: HomeViewModelable) {
        self.viewModel = viewModel
        
        viewModel.tableViewCellViewModel = { [weak self] viewModels in
            self?.dataSource = viewModels
        }
        
        viewModel.showLoader = { isShown in
            DispatchQueue.main.async {
                if isShown {
                    self.activityIndicator.startAnimating()
                } else {
                    self.activityIndicator.stopAnimating()
                }
                self.activityIndicator.isHidden = !isShown
            }
        }
    }
}

private extension HomeViewController {
    func commonInit() {
        setupHierarchy()
        setupConstraints()
    }
    
    func setupHierarchy() {
        self.view.addSubview(tableView)
        self.view.addSubview(activityIndicator)
    }
    
    func setupConstraints() {
        let viewLayoutGuide = self.view.safeAreaLayoutGuide
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        tableView.topAnchor.constraint(equalTo: viewLayoutGuide.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: viewLayoutGuide.bottomAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: viewLayoutGuide.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: viewLayoutGuide.trailingAnchor).isActive = true
        activityIndicator.centerXAnchor.constraint(equalTo: viewLayoutGuide.centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: viewLayoutGuide.centerYAnchor).isActive = true
    }
}

extension HomeViewController:
    UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.viewModel?.itemSelected(index: indexPath.row)
    }
}

extension HomeViewController:
    UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.dataSource?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PointsTableViewCell", for: indexPath) as? PointsTableViewCell,
              let cellViewModel = self.dataSource?[indexPath.row] else {
            return .init()
        }
        cell.configure(with: cellViewModel)
        return cell
    }
    
    
}
