//
//  StarWarsModel.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import Foundation


// MARK: - StarWarsModel
typealias StarWarsModel = [StarWarsMatchModel]

// MARK: - StarWarsMatchModel
struct StarWarsMatchModel: Decodable {
    let match: Int
    let player1, player2: StarWarsPlayer
}

// MARK: - Player
struct StarWarsPlayer: Decodable {
    let id, score: Int
}


