//
//  MatchTableViewCell.swift
//  StarWars
//
//  Created by Siddhartha Khanna on 21/10/23.
//

import UIKit
import UIKit

typealias MatchTableViewModel = (name: String, points: String)

final class MatchTableViewCell: UITableViewCell {
    
    private let containerStack: UIStackView = .init()
    
    private let nameLabel: UILabel = {
        let label: UILabel = .init()
        label.setContentHuggingPriority(.required, for: .horizontal)
        label.numberOfLines = 1
        return label
    }()
    
    private let pointsLabel: UILabel = {
        let label: UILabel = .init()
        label.numberOfLines = 1
        label.textAlignment = .right
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with viewModel: MatchTableViewModel) {
        self.nameLabel.text = viewModel.name
        self.pointsLabel.text = viewModel.points
    }
}

private extension MatchTableViewCell {
    func commonInit() {
        setupHierarchy()
        setupConstraints()
    }
    
    func setupHierarchy() {
        self.contentView.addSubview(containerStack)
        self.containerStack.addArrangedSubview(nameLabel)
        self.containerStack.addArrangedSubview(pointsLabel)
        
    }
    
    func setupConstraints() {
        let viewLayoutGuide = self.contentView.safeAreaLayoutGuide
        containerStack.translatesAutoresizingMaskIntoConstraints = false
        containerStack.topAnchor.constraint(equalTo: viewLayoutGuide.topAnchor, constant: 15).isActive = true
        containerStack.bottomAnchor.constraint(equalTo: viewLayoutGuide.bottomAnchor, constant: -15).isActive = true
        containerStack.leadingAnchor.constraint(equalTo: viewLayoutGuide.leadingAnchor, constant: 15).isActive = true
        containerStack.trailingAnchor.constraint(equalTo: viewLayoutGuide.trailingAnchor, constant: -15).isActive = true
        
    }
}
